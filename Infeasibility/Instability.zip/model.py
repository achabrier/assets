#Taken from https://www.ibm.com/support/pages/why-does-binary-or-integer-variable-take-noninteger-value-solution

M = 1000000  # or some other large number

from docplex.mp.model import Model
mdl = Model(name='Instability')


mdl.parameters.timelimit = 120
mdl.parameters.read.datacheck = 2
mdl.parameters.mip.tolerances.integrality = 0.001
print (mdl.parameters.mip.tolerances.integrality)
 
# --- decision variables ---
binary   = mdl.binary_var(name="bin")
var    = mdl.integer_var(name="integer", lb=0, ub=90000)

mdl.add_constraint(var <= M * binary, ctname = "constraint1")
mdl.maximize(var - binary)

mdl.solve(log_output=True)

print (binary.solution_value)
print (var.solution_value)