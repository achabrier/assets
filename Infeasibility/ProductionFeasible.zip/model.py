COSTS = {row["product"]:row["cost"] for (index,row) in inputs["products"].iterrows()}

DEMANDS = {row["product"]:row["demand"] for (index,row) in inputs["products"].iterrows()}

RESOURCES = {row["resource"]:row["capacity"] for (index,row)in inputs["resources"].iterrows()}

CONSUMPTIONS = {(row["product"],row["resource"]):row["quantity"] for (index,row)in inputs["consumptions"].iterrows()}

from docplex.mp.model import Model
import pandas as pd
import six

products = [p for p, _ in six.iteritems(COSTS)]

mdl = Model(name='pasta_production')
# --- decision variables ---
mdl.q_vars  = mdl.continuous_var_dict(products, name="q")

# --- constraints ---
# demand satisfaction
mdl.add_constraints((mdl.q_vars[p] >= DEMANDS[p], 'ct_demand_%s' % p) for p in products)

# --- resource capacity ---
mdl.add_constraints((mdl.sum(mdl.q_vars[p] * CONSUMPTIONS[p, res] for p in products) <= cap,
                     'ct_res_%s' % res) for res, cap in six.iteritems(RESOURCES))

# --- objective ---
mdl.minimize(mdl.dotf(mdl.q_vars, lambda p: COSTS[p]))

mdl.print_information()

sol = mdl.solve()

if sol is None:
    print("!! Pasta production with double demand is impossible")
            
    from docplex.mp.conflict_refiner import ConflictRefiner
    crr = ConflictRefiner().refine_conflict(mdl, display=True)
        
    from docplex.mp.relaxer import Relaxer
    rx = Relaxer()
    rs = rx.relax(mdl)
    rx.print_information()
    rs.display()
else:
    sol.display()
    outputs["production"] = pd.DataFrame(data=[[p, mdl.q_vars[p].solution_value] for p in products], columns=["product", "quantity"])